# Boostrap4_FullPages
These repository works on Bootstrap 4, SASS and etc... Download and make your upgrades, good work!!!
Open the RUN.txt to execute the bash line commands, it's make your project run perfectly.
